import os
import sys
import socket
import platform
import subprocess
import random
import string
import time
from datetime import datetime
import psutil
import requests
from threading import Thread
from PyQt5.QtWidgets import (QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, 
                           QLabel, QPushButton, QTextEdit, QTabWidget, QLineEdit, 
                           QProgressBar, QMessageBox, QFrame)
from PyQt5.QtCore import Qt, QTimer, QPropertyAnimation, QEasingCurve
from PyQt5.QtGui import QFont, QColor, QPalette, QIcon

class HackerTool(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Phonix Tool v2.0")
        self.setWindowIcon(QIcon('icon.ico'))
        self.setGeometry(100, 100, 900, 600)
        self.setStyleSheet("""
            QMainWindow {
                background-color: #0a0a0a;
                color: #00ff00;
            }
            QTabWidget::pane {
                border: 1px solid #00ff00;
                background: #121212;
            }
            QTabBar::tab {
                background: #121212;
                color: #00ff00;
                padding: 8px;
                border: 1px solid #00ff00;
            }
            QTabBar::tab:selected {
                background: #00aa00;
                color: #000000;
            }
            QPushButton {
                background-color: #003300;
                color: #00ff00;
                border: 1px solid #00ff00;
                padding: 5px;
                min-width: 80px;
            }
            QPushButton:hover {
                background-color: #005500;
            }
            QPushButton:pressed {
                background-color: #007700;
            }
            QTextEdit, QLineEdit {
                background-color: #121212;
                color: #00ff00;
                border: 1px solid #00ff00;
                font-family: Consolas;
            }
            QProgressBar {
                border: 1px solid #00ff00;
                text-align: center;
                color: #00ff00;
            }
            QProgressBar::chunk {
                background-color: #00aa00;
            }
        """)
        
        # Animatsion widgetlar ro'yxati
        self.animated_widgets = []
        
        self.initUI()
        self.initAnimations()
        
    def initUI(self):
        # Asosiy widget va layout
        main_widget = QWidget()
        self.setCentralWidget(main_widget)
        main_layout = QVBoxLayout(main_widget)
        
        # Sarlavha
        title = QLabel("Phonix Tool v2.0")
        title.setFont(QFont("Courier New", 18, QFont.Bold))
        title.setAlignment(Qt.AlignCenter)
        title.setStyleSheet("color: #00ff00; margin-bottom: 15px;")
        main_layout.addWidget(title)
        
        # Tab widget
        self.tabs = QTabWidget()
        main_layout.addWidget(self.tabs)
        
        # 1. Tizim ma'lumotlari
        self.create_system_info_tab()
        
        # 2. Port skaneri
        self.create_port_scanner_tab()
        
        # 3. Zaiflik skaneri
        self.create_vulnerability_scanner_tab()
        
        # 4. Parol generatori
        self.create_password_generator_tab()
        
        # 5. Tarmoq monitori
        self.create_network_monitor_tab()
        
        # Status paneli
        self.status_bar = self.statusBar()
        self.status_bar.setStyleSheet("color: #00ff00; background-color: #121212;")
        self.update_status("Dastur ishga tushirildi. Xush kelibsiz!")
        
    def initAnimations(self):
        # Animatsiyalar uchun timer
        self.animation_timer = QTimer(self)
        self.animation_timer.timeout.connect(self.update_animations)
        self.animation_timer.start(50)
        
    def update_animations(self):
        for widget, anim in self.animated_widgets:
            color = QColor(0, 255, 0)
            hue = (time.time() * 100) % 360
            color.setHsv(int(hue), 255, 200)
            
            style = widget.styleSheet()
            if "QLabel" in style or "QPushButton" in style:
                # Gradient yoki rang o'zgarishi
                new_style = f"color: rgb({color.red()}, {color.green()}, {color.blue()});"
                widget.setStyleSheet(style.split(";")[0] + ";" + new_style)
            else:
                # Border rang o'zgarishi
                widget.setStyleSheet(f"border: 1px solid rgb({color.red()}, {color.green()}, {color.blue()});")
    
    def create_system_info_tab(self):
        tab = QWidget()
        layout = QVBoxLayout(tab)
        
        # Animatsion sarlavha
        title = QLabel("Tizim Ma'lumotlari")
        title.setFont(QFont("Courier New", 14, QFont.Bold))
        title.setAlignment(Qt.AlignCenter)
        self.animated_widgets.append((title, None))
        
        layout.addWidget(title)
        
        # Tugma
        btn = QPushButton("Ma'lumotlarni Yuklash")
        btn.clicked.connect(self.collect_system_info)
        layout.addWidget(btn)
        
        # Natijalar maydoni
        self.system_info_output = QTextEdit()
        self.system_info_output.setReadOnly(True)
        layout.addWidget(self.system_info_output)
        
        self.tabs.addTab(tab, "Tizim Ma'lumotlari")
        
    def create_port_scanner_tab(self):
        tab = QWidget()
        layout = QVBoxLayout(tab)
        
        title = QLabel("Port Skaneri")
        title.setFont(QFont("Courier New", 14, QFont.Bold))
        title.setAlignment(Qt.AlignCenter)
        self.animated_widgets.append((title, None))
        layout.addWidget(title)
        
        # Input maydoni
        input_layout = QHBoxLayout()
        input_layout.addWidget(QLabel("IP manzil:"))
        
        self.ip_input = QLineEdit("127.0.0.1")
        input_layout.addWidget(self.ip_input)
        
        input_layout.addWidget(QLabel("Port oralig'i:"))
        
        self.port_start = QLineEdit("1")
        self.port_start.setFixedWidth(50)
        input_layout.addWidget(self.port_start)
        
        input_layout.addWidget(QLabel("-"))
        
        self.port_end = QLineEdit("1000")
        self.port_end.setFixedWidth(50)
        input_layout.addWidget(self.port_end)
        
        layout.addLayout(input_layout)
        
        # Tugma
        btn = QPushButton("Portlarni Skanerlash")
        btn.clicked.connect(self.start_port_scan)
        layout.addWidget(btn)
        
        # Progress bar
        self.scan_progress = QProgressBar()
        layout.addWidget(self.scan_progress)
        
        # Natijalar maydoni
        self.port_scan_output = QTextEdit()
        self.port_scan_output.setReadOnly(True)
        layout.addWidget(self.port_scan_output)
        
        self.tabs.addTab(tab, "Port Skaneri")
        
    def create_vulnerability_scanner_tab(self):
        tab = QWidget()
        layout = QVBoxLayout(tab)
        
        title = QLabel("Zaiflik Skaneri")
        title.setFont(QFont("Courier New", 14, QFont.Bold))
        title.setAlignment(Qt.AlignCenter)
        self.animated_widgets.append((title, None))
        layout.addWidget(title)
        
        # Tugma
        btn = QPushButton("Tizimni Tekshirish")
        btn.clicked.connect(self.check_vulnerabilities)
        layout.addWidget(btn)
        
        # Natijalar maydoni
        self.vuln_scan_output = QTextEdit()
        self.vuln_scan_output.setReadOnly(True)
        layout.addWidget(self.vuln_scan_output)
        
        self.tabs.addTab(tab, "Zaifliklar")
        
    def create_password_generator_tab(self):
        tab = QWidget()
        layout = QVBoxLayout(tab)
        
        title = QLabel("Parol Generatori")
        title.setFont(QFont("Courier New", 14, QFont.Bold))
        title.setAlignment(Qt.AlignCenter)
        self.animated_widgets.append((title, None))
        layout.addWidget(title)
        
        # Sozlamalar
        settings_layout = QHBoxLayout()
        
        settings_layout.addWidget(QLabel("Uzunlik:"))
        self.pwd_length = QLineEdit("12")
        self.pwd_length.setFixedWidth(40)
        settings_layout.addWidget(self.pwd_length)
        
        self.use_upper = QPushButton("Katta harflar")
        self.use_upper.setCheckable(True)
        self.use_upper.setChecked(True)
        settings_layout.addWidget(self.use_upper)
        
        self.use_digits = QPushButton("Raqamlar")
        self.use_digits.setCheckable(True)
        self.use_digits.setChecked(True)
        settings_layout.addWidget(self.use_digits)
        
        self.use_special = QPushButton("Maxsus belgilar")
        self.use_special.setCheckable(True)
        self.use_special.setChecked(True)
        settings_layout.addWidget(self.use_special)
        
        layout.addLayout(settings_layout)
        
        # Tugma
        btn = QPushButton("Parol Yaratish")
        btn.clicked.connect(self.generate_password)
        layout.addWidget(btn)
        
        # Natijalar maydoni
        self.password_output = QTextEdit()
        self.password_output.setReadOnly(True)
        layout.addWidget(self.password_output)
        
        self.tabs.addTab(tab, "Parol Generatori")
        
    def create_network_monitor_tab(self):
        tab = QWidget()
        layout = QVBoxLayout(tab)
        
        title = QLabel("Tarmoq Monitori")
        title.setFont(QFont("Courier New", 14, QFont.Bold))
        title.setAlignment(Qt.AlignCenter)
        self.animated_widgets.append((title, None))
        layout.addWidget(title)
        
        # Tugma
        self.monitor_btn = QPushButton("Monitoringni Boshlash")
        self.monitor_btn.clicked.connect(self.toggle_network_monitor)
        layout.addWidget(self.monitor_btn)
        
        # Natijalar maydoni
        self.network_output = QTextEdit()
        self.network_output.setReadOnly(True)
        layout.addWidget(self.network_output)
        
        self.tabs.addTab(tab, "Tarmoq Monitori")
        
        # Monitoring uchun timer
        self.monitor_timer = QTimer(self)
        self.monitor_timer.timeout.connect(self.update_network_info)
        self.is_monitoring = False
        
    # ===== FUNKSIYALAR =====
    
    def collect_system_info(self):
        self.system_info_output.clear()
        info = ""
        
        # Tizim ma'lumotlari
        info += "=== TIZIM MA'LUMOTLARI ===\n"
        info += f"Operatsion tizim: {platform.system()} {platform.release()}\n"
        info += f"Versiya: {platform.version()}\n"
        info += f"Tizim arxitekturasi: {platform.machine()}\n"
        info += f"Protsessor: {platform.processor()}\n"
        info += f"Foydalanuvchi: {os.getlogin()}\n\n"
        
        # Xotira ma'lumotlari
        mem = psutil.virtual_memory()
        info += "=== XOTIRA MA'LUMOTLARI ===\n"
        info += f"Umumiy xotira: {mem.total / (1024**3):.2f} GB\n"
        info += f"Foydalanilayotgan: {mem.used / (1024**3):.2f} GB\n"
        info += f"Bo'sh xotira: {mem.available / (1024**3):.2f} GB\n\n"
        
        # Disk ma'lumotlari
        info += "=== DISK MA'LUMOTLARI ===\n"
        for part in psutil.disk_partitions():
            try:
                usage = psutil.disk_usage(part.mountpoint)
                info += f"Disk: {part.device}\n"
                info += f"  Fayl tizimi: {part.fstype}\n"
                info += f"  Umumiy hajm: {usage.total / (1024**3):.2f} GB\n"
                info += f"  Foydalanilgan: {usage.used / (1024**3):.2f} GB\n"
                info += f"  Bo'sh joy: {usage.free / (1024**3):.2f} GB\n\n"
            except:
                continue
        
        # Tarmoq ma'lumotlari
        info += "=== TARMOQ MA'LUMOTLARI ===\n"
        for name, addrs in psutil.net_if_addrs().items():
            info += f"Interfeys: {name}\n"
            for addr in addrs:
                info += f"  {addr.family.name}: {addr.address}\n"
            info += "\n"
        
        self.system_info_output.setPlainText(info)
        self.update_status("Tizim ma'lumotlari muvaffaqiyatli yuklandi")
        
    def start_port_scan(self):
        ip = self.ip_input.text()
        try:
            start_port = int(self.port_start.text())
            end_port = int(self.port_end.text())
            
            if start_port < 1 or end_port > 65535 or start_port > end_port:
                QMessageBox.warning(self, "Xato", "Noto'g'ri port oralig'i! (1-65535)")
                return
                
            self.port_scan_output.clear()
            self.scan_progress.setRange(0, end_port - start_port)
            self.scan_progress.setValue(0)
            
            # Skanni alohida threadda bajarish
            self.scan_thread = Thread(target=self.scan_ports, args=(ip, start_port, end_port))
            self.scan_thread.start()
            
        except ValueError:
            QMessageBox.warning(self, "Xato", "Port raqamlarini to'g'ri kiriting!")
            
    def scan_ports(self, ip, start_port, end_port):
        open_ports = []
        for port in range(start_port, end_port + 1):
            try:
                sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                sock.settimeout(0.5)
                result = sock.connect_ex((ip, port))
                
                if result == 0:
                    try:
                        service = socket.getservbyport(port)
                    except:
                        service = "noma'lum"
                    
                    open_ports.append((port, service))
                    text = f"[+] Port {port} ochiq ({service})"
                    self.port_scan_output.append(text)
                
                sock.close()
                
                # Progress bar yangilash
                self.scan_progress.setValue(port - start_port)
                
            except Exception as e:
                self.port_scan_output.append(f"Xato: {str(e)}")
                continue
                
        self.update_status(f"Port skaneri yakunlandi. {len(open_ports)} ta ochiq port topildi")
        
    def check_vulnerabilities(self):
        self.vuln_scan_output.clear()
        self.vuln_scan_output.append("=== TIZIM ZAIFLIKLARI TEKSHIRILMOQDA ===\n")
        
        # 1. Eski Windows versiyalari
        win_ver = platform.version()
        if int(win_ver.split('.')[2]) < 19041:  # Windows 10 20H1
            self.vuln_scan_output.append("[!] Eski Windows versiyasi - xavfli!")
        else:
            self.vuln_scan_output.append("[+] Windows versiyasi yangi - xavfsiz")
        
        # 2. UAC holati
        try:
            uac = subprocess.check_output("REG QUERY HKLM\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Policies\\System /v EnableLUA", shell=True)
            if "0x1" in str(uac):
                self.vuln_scan_output.append("[+] UAC yoqilgan - yaxshi")
            else:
                self.vuln_scan_output.append("[!] UAC o'chirilgan - xavfli!")
        except:
            self.vuln_scan_output.append("[?] UAC holatini aniqlab bo'lmadi")
        
        # 3. Firewall holati
        try:
            firewall = subprocess.check_output("netsh advfirewall show allprofiles state", shell=True)
            if "ON" in str(firewall):
                self.vuln_scan_output.append("[+] Firewall yoqilgan - yaxshi")
            else:
                self.vuln_scan_output.append("[!] Firewall o'chirilgan - xavfli!")
        except:
            self.vuln_scan_output.append("[?] Firewall holatini aniqlab bo'lmadi")
        
        # 4. Antivirus tekshirish
        try:
            wmi = subprocess.check_output("wmic /namespace:\\\\root\\securitycenter2 path antivirusproduct get displayName", shell=True)
            if "No Instance" not in str(wmi):
                self.vuln_scan_output.append("[+] Antivirus o'rnatilgan - yaxshi")
                self.vuln_scan_output.append(f"   Antivirus: {str(wmi).split('\\r\\r\\n')[1]}")
            else:
                self.vuln_scan_output.append("[!] Antivirus o'rnatilmagan - xavfli!")
        except:
            self.vuln_scan_output.append("[?] Antivirus holatini aniqlab bo'lmadi")
        
        self.vuln_scan_output.append("\n=== TEKSHIRUV YAKUNLANDI ===")
        self.update_status("Zaifliklar tekshiruvi yakunlandi")
        
    def generate_password(self):
        try:
            length = int(self.pwd_length.text())
            if length < 4 or length > 64:
                QMessageBox.warning(self, "Xato", "Parol uzunligi 4-64 oralig'ida bo'lishi kerak!")
                return
                
            chars = string.ascii_lowercase
            if self.use_upper.isChecked():
                chars += string.ascii_uppercase
            if self.use_digits.isChecked():
                chars += string.digits
            if self.use_special.isChecked():
                chars += "!@#$%^&*()_+-=[]{}|;:,.<>?"
                
            password = ''.join(random.choice(chars) for _ in range(length))
            self.password_output.setPlainText(password)
            self.update_status("Yangi parol yaratildi")
            
        except ValueError:
            QMessageBox.warning(self, "Xato", "Parol uzunligini to'g'ri kiriting!")
            
    def toggle_network_monitor(self):
        if self.is_monitoring:
            self.monitor_timer.stop()
            self.monitor_btn.setText("Monitoringni Boshlash")
            self.is_monitoring = False
            self.update_status("Tarmoq monitoringi to'xtatildi")
        else:
            self.network_output.clear()
            self.monitor_timer.start(2000)  # Har 2 soniyada yangilash
            self.monitor_btn.setText("Monitoringni To'xtatish")
            self.is_monitoring = True
            self.update_status("Tarmoq monitoringi boshlandi")
            
    def update_network_info(self):
        info = "=== TARMOQ FAOLLIGI ===\n"
        info += f"Vaqt: {datetime.now().strftime('%H:%M:%S')}\n\n"
        
        # Tarmoq ulanishlari
        connections = psutil.net_connections()
        info += f"Faol ulanishlar: {len(connections)}\n"
        
        # IP manzil
        try:
            external_ip = requests.get('https://api.ipify.org').text
            info += f"Tashqi IP: {external_ip}\n\n"
        except:
            info += "Tashqi IP aniqlanmadi\n\n"
        
        # Tarmoq statistikasi
        net_io = psutil.net_io_counters()
        info += "=== TRAFIK STATISTIKASI ===\n"
        info += f"Yuborilgan: {net_io.bytes_sent / (1024**2):.2f} MB\n"
        info += f"Qabul qilingan: {net_io.bytes_recv / (1024**2):.2f} MB\n"
        
        self.network_output.setPlainText(info)
        
    def update_status(self, message):
        self.status_bar.showMessage(f"Status: {message}")
        
    def closeEvent(self, event):
        if hasattr(self, 'is_monitoring') and self.is_monitoring:
            self.monitor_timer.stop()
        event.accept()

if __name__ == "__main__":
    app = QApplication(sys.argv)
    
    # Qo'shimcha stil
    app.setStyle('Fusion')
    palette = QPalette()
    palette.setColor(QPalette.Window, QColor(10, 10, 10))
    palette.setColor(QPalette.WindowText, QColor(0, 255, 0))
    palette.setColor(QPalette.Base, QColor(18, 18, 18))
    palette.setColor(QPalette.AlternateBase, QColor(30, 30, 30))
    palette.setColor(QPalette.ToolTipBase, QColor(0, 255, 0))
    palette.setColor(QPalette.ToolTipText, QColor(0, 255, 0))
    palette.setColor(QPalette.Text, QColor(0, 255, 0))
    palette.setColor(QPalette.Button, QColor(0, 51, 0))
    palette.setColor(QPalette.ButtonText, QColor(0, 255, 0))
    palette.setColor(QPalette.BrightText, Qt.red)
    palette.setColor(QPalette.Highlight, QColor(0, 170, 0))
    palette.setColor(QPalette.HighlightedText, Qt.black)
    app.setPalette(palette)
    
    window = HackerTool()
    
    # Animatsion ochilish effekti
    opacity_animation = QPropertyAnimation(window, b"windowOpacity")
    opacity_animation.setDuration(1000)
    opacity_animation.setStartValue(0)
    opacity_animation.setEndValue(1)
    opacity_animation.setEasingCurve(QEasingCurve.InOutQuad)
    opacity_animation.start()
    
    window.show()
    sys.exit(app.exec_())
